#include <iostream>
#include "p.h"

int main() {
    Person blaz = Person("Blaz");
    std::cout << "Dober dan" << blaz.name << '\n';
}
