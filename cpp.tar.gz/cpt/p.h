#include <string>

class Person {
public:
    std::string name;
    Person(std::string _name);

};
