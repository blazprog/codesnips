#include <string>
#include "p.h"

Person::Person(std::string _name) {
    name = _name;
}

